data:extend({
	{
		type = "sound",
		name = "deathscream",
		variations =
		{
			{
				filename = '__BugZilla__/sounds/deathscream.ogg',
				volume = 1
			},
		},
	}
})
