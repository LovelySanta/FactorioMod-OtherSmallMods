data:extend{
  {
		type = "int-setting",
		name = "SNTD-nixie-tube-update-speed",
		setting_type = "runtime-global",
		minimum_value = 1,
		default_value = 5,
		order = "nixie-speed-numeric",
	},
}
