-- BugZilla
require("prototypes.bugzilla")

-- GUI
require("prototypes.gui")

-- Deathscream
require("prototypes.deathscream")
