require ("prototypes/bugzilla-entities")
require ("prototypes/bugzilla-builder")

-- Creating bugs
BZ_bugzilla.functions.make_alien(bugzilla_biter)
