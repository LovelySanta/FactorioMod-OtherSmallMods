data:extend{
  {
    -- Fixed cliff settings
    type = "bool-setting",
    name = "LM-disable-landfill-recipe",
    setting_type = "startup",
    default_value = true,
    order = "LM-a[landfill]-d",
  },
}
