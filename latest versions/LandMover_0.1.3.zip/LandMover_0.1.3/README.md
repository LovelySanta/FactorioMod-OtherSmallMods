# Changelog
Version 0.1.2
* Bugfix entity sprite size not correctly
* Changed stack size to 100 to match the stack size of landfill
* Changed recipe to use an actual shovel (+ added shovel entity)
-------------------------------------------------------------------------------
Version 0.1.1
* Changed to a 'decent' recipe
-------------------------------------------------------------------------------
Version 0.1.0
* Initial version: Removing production of landfill, Replaced it by Land Mover

# Credit
-------------------------------------------------------------------------------
* Based on the mod waterfill by ceryss, started by Riley19280
  Homepage: https://mods.factorio.com/mods/ceryss/Waterfill_v15

* Special thanks to geilolo for the design of the pictures (tech and entity symbols)
