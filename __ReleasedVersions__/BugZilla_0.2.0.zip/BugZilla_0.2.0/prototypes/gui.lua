data:extend({
  {
    type = "sprite",
    name = "death-skull",
    filename = "__BugZilla__/graphics/sprites/death-skull.png",
    priority = "extra-high",
    width = 256,
    height = 256,
  },
})
