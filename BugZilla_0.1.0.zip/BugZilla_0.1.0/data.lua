require("prototypes.bugzilla")

require("prototypes.deathscream")
require("prototypes.corpse-flare")
