# Changelog
-------------------------------------------------------------------------------
Version 0.1.0
* Initial version: Removing production of landfill, Replaced it by Land Mover

# Credit
-------------------------------------------------------------------------------
* Based on the mod waterfill by ceryss, started by Riley19280
  Homepage: https://mods.factorio.com/mods/ceryss/Waterfill_v15

* Special thanks to geilolo for the design of the pictures (tech and entity symbols)