require("prototypes.corpse-flare")
